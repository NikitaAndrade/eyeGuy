package com.example.front_end_eyebuddy;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity10 extends AppCompatActivity {

    Button finishButton;
    Button startPrompt;
    TextView timerNum2;
    TextView PointShow;
    Thread thread;
    int counter;
    int points;
    int numDown;
    int twentySec;
    int testNum;
    int min;
    int seconds;

    boolean isFinished;
    boolean isFinishing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);
        finishButton = findViewById(R.id.finishPromptButton);
        startPrompt = findViewById(R.id.startPrompt);
        timerNum2 = findViewById(R.id.twentynumber);
        PointShow = findViewById(R.id.textView2);
        isFinishing = true;
        twentySec =20;
        counter = 0;
        numDown = 20;

        startPrompt.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                if (isFinishing == true){
                    while (isFinishing == true){
                        try {
                            Thread.sleep(1000);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    String timeNumberText = String.format(Locale.getDefault(),"%02d:%02d",min,seconds);
                                    timerNum2.setText(timeNumberText);
                                    counter++;
                                    numDown--;
                                    min = numDown /60;
                                    seconds = numDown % 60;
                                    Log.d("twenty", "Finishing button is ready in: " + numDown);
                                    Log.d("Twentieth", min + " : " + seconds);
                                    if (counter == twentySec){
                                        isFinishing = false;
                                        isFinished = true;
                                        counter = 0;
                                    }
                                }
                            });

                        } catch (InterruptedException e) {
                        }
                    }



                }else{
                    Log.d("promptHandle","wait 20 minutes before you can start your prompt.");

                }

            }


        });
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isFinished == true){
                    Log.d("PointsUp","+100 points");
                    saveDataInSharedPreferences(points);
                    isFinished = false;
                    numDown = testNum;
                    Log.d("total", "TOTAL POINTS:" + retrieveData());
                    String PointShown = String.format(Locale.getDefault(),"",retrieveData());
                    PointShow.setText(PointShown);
                    startActivity(new Intent(MainActivity10.this, MainActivity6.class));
                }else{
                    Log.d("noPoints","There is no prompt to claim any prize. Loser");
                }
            }

        });
    }
    private void saveDataInSharedPreferences(int points) {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        int prevPoints = sharedPreferences.getInt("points",0);
        int prompComplete = sharedPreferences.getInt("prompComp",0);
        prompComplete += 1;
        prevPoints += points;
        myEdit.putInt("points",prevPoints);
        myEdit.commit();
    }
    private int retrieveData(){
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
        return sharedPreferences.getInt("points",0);
    }

}
package com.example.front_end_eyebuddy;

import static com.example.front_end_eyebuddy.App.CHANNEL_1_ID;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity6 extends AppCompatActivity {

    public String notifTitle;
    public String notifContent;
    Button startButton;
    Button stopButton;
    Button finishButton;
    Button startPrompt;
    TextView timerNum;
    Thread thread;
    int counter;
    int points;
    int numDown;
    int twentyMin;
    int twentySec;
    int testNum;
    int min;
    int seconds;
    boolean isRunning;
    boolean isFinished;
    boolean isFinishing;
    private NotificationManagerCompat notificationManager;

    private String prompts[] = {"Look and touch the first 3 green things you see.","Look and touch the first 3 blue things you see.","Get active and try to do 10 jumping-jacks!","Get active and try to stretch your arms!","Go and water that plant you forgot about!","Get up and try to get a snack!","Interact with the person you see on your left.","Interact with the person you see on your right.","Run to the fastest open window you see and take a big deep,breath!","Use this time to go to the bathroom.","Eye spy with my little eye, something that is my favourite colour.","Eye need you to drink water. Now.","Time's up! Take a break!","Eye spy with my little eye, something warm and fuzzy!","Look at something you love.","Take a walk, stand up!"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        startButton = findViewById(R.id.start);
        stopButton = findViewById(R.id.stop);
        timerNum = findViewById(R.id.twentynumber);
        points = 100;
        thread = null;
        isRunning = false;
        counter = 0;
        testNum = 12;
        twentySec = 20;
        twentyMin = testNum;
        numDown = testNum;
        min = numDown / 60;
        seconds = numDown % 60;
        isFinished = false;
        isFinishing = false;
        notificationManager = NotificationManagerCompat.from(this);
        notifTitle = "Twenty is up!";
        notifContent = prompts[0];

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_1_ID)
                .setSmallIcon(R.drawable.eyeguyicon)
                .setContentTitle(notifTitle)
                .setContentInfo(notifContent)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isRunning == true && isFinishing == false){
                    Log.d("Debounce", "Already Running");
                }else{
                    thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            isRunning = true;
                            while (isRunning) {
                                try {
                                    Thread.sleep(1000);
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            String timeNumberText = String.format(Locale.getDefault(),"%02d:%02d",min,seconds);
                                            timerNum.setText(timeNumberText);
                                            counter++;
                                            numDown --;
                                            min = numDown /60;
                                            seconds = numDown % 60;
                                            Log.d("timer", min + " : " + seconds);
                                            Log.d("Time", "run: " + numDown);
                                            if (counter == testNum){
                                                isRunning = false;
                                                isFinishing = true;
                                                counter = 0;
                                                numDown = twentySec;
                                                notificationManager.notify(1,notification);
                                                startActivity(new Intent(MainActivity6.this, MainActivity10.class));
                                            }
                                        }
                                    });
                                } catch (InterruptedException e) {
                                }
                            }
                        }
                    });
                    thread.start();
                }

            }
        });
        //
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isRunning = false;
                counter = 0;
                if(thread != null){
                    try {
                        thread.interrupt();
                    }catch (Exception e){

                    }

                }

            }
        });
        /*
        startPrompt.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                if (isFinishing == true){
                    while (isFinishing == true){
                        try {
                            Thread.sleep(1000);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    String timeNumberText = String.format(Locale.getDefault(),"%02d:%02d",min,seconds);
                                    timerNum.setText(timeNumberText);
                                    counter++;
                                    numDown--;
                                    min = numDown /60;
                                    seconds = numDown % 60;
                                    Log.d("twenty", "Finishing button is ready in: " + numDown);
                                    Log.d("Twentieth", min + " : " + seconds);
                                    if (counter == twentySec){
                                        isFinishing = false;
                                        isFinished = true;
                                        counter = 0;
                                    }
                                }
                            });

                        } catch (InterruptedException e) {
                        }
                    }



                }else{
                    Log.d("promptHandle","wait 20 minutes before you can start your prompt.");

                }

            }


        });

        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isFinished == true){
                    Log.d("PointsUp","+100 points");
                    saveDataInSharedPreferences(points);
                    isFinished = false;
                    numDown = testNum;
                    Log.d("total", "TOTAL POINTS:" + retrieveData());
                }else{
                    Log.d("noPoints","There is no prompt to claim any prize. Loser");
                }
            }

        });

    }

    private void saveDataInSharedPreferences(int points) {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        int prevPoints = sharedPreferences.getInt("points",0);
        int prompComplete = sharedPreferences.getInt("prompComp",0);
        prompComplete += 1;
        prevPoints += points;
        myEdit.putInt("points",prevPoints);
        myEdit.commit();
    }
    private int retrieveData(){
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
        return sharedPreferences.getInt("points",0);
    */}

}
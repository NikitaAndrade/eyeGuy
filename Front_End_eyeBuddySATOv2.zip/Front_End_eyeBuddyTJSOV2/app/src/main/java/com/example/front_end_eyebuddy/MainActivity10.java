package com.example.front_end_eyebuddy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity10 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);

        Button button = findViewById(R.id.stop);
        button.setOnClickListener(view -> startActivity(new Intent(MainActivity10.this, MainActivity11.class)));

    }

}